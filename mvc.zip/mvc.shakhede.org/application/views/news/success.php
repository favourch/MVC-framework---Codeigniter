<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?><!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
</head>

 <div class="container">
 <div class="panel panel-default">
  <div class="panel-heading">Thank You!</div>
  <div class="panel-body">
                           <p>Your article has been successfully submitted..</p>


 </div>
  
 <div class="panel-footer">
	Copyrights &COPY; 2015. All rights reserved.
      </div>
 </div>




   
<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?><!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
</head>

<div class="container">
    <div class="panel panel-default">
        <div class="panel-heading">Message send</div>
        <div class="panel-body">
            
            <p>Your message has been sent successfully!</p>


        </div>







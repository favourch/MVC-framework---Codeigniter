<div class="container">
	<div class="panel panel-default">
	<div class="panel-heading"><?php echo $title; ?></div>
		<div class="panel-body">
        <p><?= $verify; ?></p>
</div>